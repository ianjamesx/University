#ifndef DEBUG
#define DEBUG

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <mpi.h>
#include <time.h>

static bool debug = false;
static bool logtofile = true;

#endif
