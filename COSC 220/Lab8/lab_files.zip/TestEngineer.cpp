#include <iostream>
#include <string>
#include "TestEngineer.h"
using namespace std;

TestEngineer::TestEngineer(string fn, string ln, string title, int base, int profit){

  firstname = fn;
  lastname = ln;
  jobTitle = title;
  baseSalary = base;
  profitSharing = profit;

}
