#include <stdio.h>
#include <utmp.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

int openUtmpFile(){

  //open utmp file as readonly
  int fdes = open("/var/run/utmp", O_RDONLY);

  //ensure its open
  if(fdes < 0){
    printf("Unable to open utmp file\n");
    exit(-1);
  }

  return fdes;

}

int main(int argc, char **argv){

  int filedes = openUtmpFile(); //file des for utmp

  printf("Opened Utmp file\n");

  close(filedes);

  return 0;

}
