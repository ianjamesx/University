#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>


int main(int argc, char **argv){

  pid_t pid;
  pid_t pidgc;
  int exitcode;
  int i;

  pid = fork();

  switch (pid) {
    case -1:
        perror("fork failed");
    break;
    case 0:
        pidgc = fork();
        
        if(pidgc == 0){

            for(;;) {

                printf("I am your grandchild\n");

                //check if child has terminated
                int stat_val;
                pid_t result_pid = waitpid(pid, &stat_val, WNOHANG);
                if(result_pid > 0){
                    break;
                }

                sleep(1);
            }

        } else {

            for(i = 0; i < 100; i++){
                printf("I am your child\n");
            }

        }  
        


    break;
    default:
      
        for(;;) {

            printf("I am parent\n");

            //check if child has terminated
            int stat_val;
            pid_t result_pid = waitpid(pid, &stat_val, WNOHANG);
            if(result_pid > 0){
                printf("I finish my job\n");
                break;
            }

            sleep(1);
        }
      
    break;
  }

  return 0;

}