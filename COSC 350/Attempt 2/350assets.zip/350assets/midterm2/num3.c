
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int counter = 0; //counter

pthread_mutex_t count_mutex = PTHREAD_MUTEX_INITIALIZER; //mutex (for race condition)

void* increase(){
    while(1){
        if(counter < 10){
            pthread_mutex_lock(&count_mutex); //lock the critical section
            counter++;
            printf("counter is now %d\n", counter);
            sleep(1);
            pthread_mutex_unlock(&count_mutex); //unlock
        }
    }
}

void* decrease(){
    while(1){
        if(counter > 0){
            pthread_mutex_lock(&count_mutex);
            counter--;
            printf("counter is now %d\n", counter);
            sleep(1);
            pthread_mutex_unlock(&count_mutex);
        }
    }
}

int main(){


  //Creating our threads
  pthread_t inc_t;
  pthread_t dec_t;

  int inc_pt = pthread_create(&inc_t, NULL, increase, NULL);
  int dec_pt = pthread_create(&dec_t, NULL, decrease, NULL);

  pthread_join(inc_t, NULL);
  pthread_join(dec_t, NULL);

  return 0;
}
