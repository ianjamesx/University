#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

//Receive any data from keyboard and write on standard output
//This program keeps asking data until EOF. (only use I/O system calls)

int main(){

    //EOF is a set int value, may vary system to system
    //can print it here to tell user what it is on their system
    printf("Enter some data, to exit, enter %d\n", EOF);

    char b[1];
    int nread;
    while ((nread = read(0, b, 1) > 0)){
        if(b[1] == EOF){
            break;
        }
        write (1, b, nread); //write to stdout
    }

    return 0;
}