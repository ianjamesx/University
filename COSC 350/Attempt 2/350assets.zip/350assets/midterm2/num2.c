
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

int main(){
  
    char *cmd = "./anyinput"; //program from #1
    char buf[256];
    FILE *ptr;
    int a, b;
    if ((ptr = popen(cmd, "r")) != NULL){
        while (fgets(buf, 256, ptr) != NULL){
            if(sscanf(buf, "%d %d", &a, &b)!=2){
                printf("Invalid input: two integer\n"); //invalid input
            } else {
                char output[256];
                sprintf(output, "%d\n", (a*b));
                printf("%d * %d = %s", a, b, output);
                
            }
        }
    }

    pclose(ptr);
    return 0;
  
}
