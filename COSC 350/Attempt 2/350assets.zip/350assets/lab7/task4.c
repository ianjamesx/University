//task4
//child sends signals to parent, parent prints messages

#include <signal.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

void handler(int sig){
  if(sig==SIGUSR1){
    printf("Hi Honey! Anything wrong?\n");
  } else if(sig==SIGUSR2){
    printf("Do you make trouble again?\n");
  }
}

int main(){
  signal(SIGUSR1, handler);
  signal(SIGUSR2, handler);
  
  int status = 0;

  pid_t c1 = fork(), c2;
  if(c1 != 0){ //if not the child we just made
    c2 = fork(); //create another child process
    if(c2 != 0){ //if not child, parent kills both children
      kill(c1, SIGUSR1);
      kill(c2, SIGUSR2);
    }
  }
  wait(&status);
  wait(&status);
  return 0;
}
