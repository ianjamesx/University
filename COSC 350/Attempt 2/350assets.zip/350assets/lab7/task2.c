
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

void ouch(int sig){
  printf("OUCH - I got a signal %d\n", sig);
}

int main(){
  
  struct sigaction act;

  act.sa_handler = ouch;
  sigemptyset(&act.sa_mask);
  act.sa_flags=SA_RESETHAND;
  
  /* about SA_RESETHAND flag from man pages:
   restore the signal action to the default upon entry to the
   signal handler.  This flag is meaningful only when establishing
   a signal handler
   */

  sigaction(SIGINT, &act,0);

  while(1){
    printf("Hello world!\n");
    sleep(1);
  }
  
  return 0;
}
