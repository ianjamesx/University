//task3
//child writes 'hi mom' to file
//parent reads file, prints
//no need to check for errs

#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>

int main(){

  umask(0);
  int status = 0;
  
  int fd1 = open("foo", O_CREAT | O_RDWR, 0666);
  int fd2 = dup(fd1);
  pid_t pid = fork();

  if(pid == 0){ //child process
    write(fd2, "Hi, Mom", 7); //child says 'hi mom'
    close(fd2);
    return 0;
  }

  wait(&status); //make parent wait for child
  lseek(fd1, SEEK_SET, 0);
  char rbuf[7]; //We are making our buffer 7 since we know exactly how much we're writing.
  read(fd1, rbuf, 7);
  printf("My son said %s\n", rbuf);
  close(fd1);

  return 0;

}
