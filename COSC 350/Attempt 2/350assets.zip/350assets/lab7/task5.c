

#include <signal.h>
#include <stdio.h>
#include <unistd.h>

void handler(int sig){
 if(sig==SIGQUIT){
   printf("SIGQUIT pressed during the loop\n");
 } else if(sig==SIGINT) {
   printf("SIGINT pressed during the loop\n");
 }
 printf("\n");
}

int main(){

 sigset_t new_set, old_set;
 
 //Clear all signals
 sigemptyset(&new_set);
 
 // Add the two signals to the signal set
 sigaddset(&new_set, SIGINT);
 
 sigaddset(&new_set, SIGQUIT);
 sigprocmask(SIG_BLOCK, &new_set, &old_set);

 //first loop, block both
 int i;
 for(i=0; i<5; i++){
   printf("First loop [SIGINT & SIGQUIT blocked]: %d\n", i);
   sleep(1);
 }

 printf("Unblocking SIGQUIT\n");
 
 //Now, let's redirect the handler to a custom handler for the unblock operation, since if we don't it'll exit.
 signal(SIGINT, handler);
 signal(SIGQUIT, handler);
 
 //Reset to default mask
 sigprocmask(SIG_SETMASK, &old_set, NULL);
 
 //Edit our mask to only include SIGINT
 sigdelset(&new_set, SIGQUIT);
 sigprocmask(SIG_BLOCK, &new_set, NULL);
 
 //Reset the handlers
 signal(SIGINT, SIG_DFL);
 signal(SIGQUIT, SIG_DFL);
 
 //second loop, only SIGINT is blocked 
 for(i=0; i<5; i++){
   printf("Second loop [SIGINT blocked]: %d\n", i);
   sleep(1);
 }
 
}
