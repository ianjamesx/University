#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int stringtoint(char *c){

  //convert string to int
  int i = 0;
  long int num = 0;
  while(c[i] != '\0'){
    num = 10 * num + (c[i] - '0');
    i++;
  }

  return num;

}

int main(int argc, char **argv){

  //umask(0);

  if(argc != 2){

    printf("Usage: ./task5 [inputfile]\n");
    return 0;

  }

  int infile;

  if((infile = open(argv[1], O_RDONLY) < 0)){
    printf("Err, cannot open file\n");
    return 0;
  }

  printf("%d\n", infile);

  int filesize = lseek(infile, (off_t)0, SEEK_END);
  printf("filesize: %d\n", filesize);
  pid_t pid;
  pid = fork();

  int childout, parentout;

  char buffer;
  int i;

  int lowerDigit = '0',
      upperDigit = '9';

  switch(pid){

    case -1:
      perror("fork failed");
      return 0;
    case 0:

    //child process

    /*
    get file size with lseek
    parent child for loop
    lseek, read, write, increase stored offset
    */

      if((childout = open("child.txt", O_WRONLY | O_CREAT, 0666) == -1)){
        printf("err, cannot open output child file\n");
        return 0;
      }

      for(i = 0; i < filesize; i++){

        lseek(infile, (off_t)i, SEEK_SET);
        read(infile, &buffer, 1);
        if(!((int)buffer >= lowerDigit && (int)buffer <= upperDigit)){
          printf("child: %c\n", buffer);
          write(childout, &buffer, 1);
        }
      }

    break;
    default:
      //parent process

      if((parentout = open("parent.txt", O_WRONLY | O_CREAT, 0666) == -1)){
        printf("err, cannot open output parent file\n");
        return 0;
      }

      for(i = 0; i < filesize; i++){

        lseek(infile, (off_t)i, SEEK_SET);
        read(infile, &buffer, 1);
        if((int)buffer >= lowerDigit && (int)buffer <= upperDigit){
          printf("parent: %c\n", buffer);
          write(parentout, &buffer, 1);
        }
      }

    break;
  }

  return 0;

}