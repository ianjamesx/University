#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

int isNumeric(char c){

  int lowerDigit = '0',
      upperDigit = '9';
  int coerce = c;

  //printf("%d, %d", lowerDigit, upperDigit);

  if(coerce >= lowerDigit && coerce <= upperDigit){
    return 1;
  }

  return 0;

}

int main(int argc, char **argv){

  if(argc < 2){
    printf("Usage: ./task5 [input]\n");
    return 0;
  }

  char *infile = argv[1], *childout = "child.txt", *parentout = "parent.txt";
  int filedes[3];

  //open up foo file to read from
  filedes[0] = open(infile, O_RDONLY);
  if(filedes[0] == -1){
    printf("Can't open input file\n");
    return 0;
  }

  //open up clone1 file, we will want read/write on users, groups, others
  umask(0);
  filedes[1] = open(childout, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
  filedes[2] = open(parentout, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);

  int size = lseek(filedes[0], 0, SEEK_END);

  int offset1, offset2;

  //printf("Opened files with filedes: %d, %d, %d\n", filedes[0], filedes[1], filedes[2]);

  //create buffer to hold one char (one byte)
  char buffer[1];
  int nread;


/*  while ((nread = read(filedes[0], buffer, 1) > 0)){
    //printf("reading: %d, %c\n", nread, buffer[0]);
    //write to clone1
    write(filedes[1], buffer, nread);
  }
*/

  //int filesize = lseek(infile, (off_t)0, SEEK_END);
  pid_t pid = 1;
  pid = fork();
  printf("Forked to id: %d\n", pid);

  switch(pid){

    case -1:
      printf("fork failed\n");
      return 0;

    case 0:

    //child process

      while ((nread = read(filedes[0], buffer, 1) > 0)){
        printf("reading %c", buffer[0]);
        if(isNumeric(buffer[0]) == 0){
          write(filedes[1], buffer, nread);
        }
      }

    break;
    default:

    //parent

      while ((nread = read(filedes[0], buffer, 1) > 0)){
        if(isNumeric(buffer[0]) == 1){
          write(filedes[2], buffer, nread);
        }
      }

    break;
  }
  





  close(filedes[0]);
  close(filedes[1]);
  close(filedes[2]);

  return 0;

}