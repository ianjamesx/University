/* Wait for a thread for concurrent calculations 
 * Thread #1: Get test scores from a keyboard up to 20 and save into the array.
 * Thread #2: Calculate an average score and Medium value and display.
 * Thread #3: get hte minimum and the maximum score and display
 * Thread #4: Clear buffer and set to 0 and display after thread #2, thread #3 finishes its job.
 * Thread #2 and #3 must wait for thread #1 to finish its job. Once thread #1 finishes its job, thread #2 and thread #3 works concurrently. Thread#4 must wait for thread #2 and Thread #3 finishes its job.
 * */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>


int a[20]; //Array
int n=0; //Array size

void* printArr(){
    for(int i=0; i<n; i++){
        printf("%d ", a[i]);
    }
    printf("\n");
}
void* getScores(){
    char buf[256];
    int ibuf=0;

    printf("enter scores (press enter after each score), -1 to end input loop\n");

    for(int i=0; i<20; i++){
        printf("score[%d] : ", i);
        scanf("%s", buf);
        ibuf = atoi(buf);
        if(ibuf == -1){
            break;
        } else {
            a[i] = ibuf;
            n++;
        }
    }
    
    int x=0, y=0;
    
    //Sorting (pretty slow, only 20 elements though)
    for(int i=0; i<n-1; i++){
        for(int j=i; j<n; j++){
            if(a[i] > a[j]){
                x=a[i];
                y=a[j];
                a[j]=x;
                a[i]=y;
            }
        }
    }
    printf("\nArray stats\n\nNumber of elements %d\nArray entered: ", n);
    printArr();
}

void* average(){
    float avg=0;
    for(int i=0; i<n; i++)
        avg+=a[i];
    avg/=n;    
    printf("Median (middle value value at a[n/2]): \n");
    printf("Average Score: %f\nMedian Score %d\n",avg, a[n/2]);
}

void* minmax(){
    printf("Min: %d\nMax %d\n", a[0], a[n-1]);
}

void* clearbuf(void *param){
    
    pthread_t *p = (pthread_t*) param;
    pthread_join(p[0], NULL);
    pthread_join(p[1], NULL);
    for(int i=0; i<n; i++){
        a[i]=0;
    }
}

int main(int argc, char **argv){
   
    //Creating threads
    pthread_t score_t;
    pthread_t avg_t;
    pthread_t max_t;
    pthread_t buf_t;
    
    //create threads for scores
    int score_pt = pthread_create(&score_t, NULL, getScores, NULL);
    pthread_join(score_t, NULL);
    
    //create threads for calculating avg and min/max
    int avg_pt = pthread_create(&avg_t, NULL, average, NULL);
    int max_pt = pthread_create(&max_t, NULL, minmax, NULL); 

    pthread_t arr[2] = { avg_t, max_t };

    //thread for clearing buffer
    int buf_pt = pthread_create(&buf_t, NULL, clearbuf, arr); 
    pthread_join(buf_t, NULL); 

    printf("buffer cleared\nfinal array: ");
    printArr();
    return 0;
}
