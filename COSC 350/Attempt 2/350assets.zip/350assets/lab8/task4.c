/* Interprocess communication using popen() and pclose()
 * popen() create a child and pipe. A parent process asks two arguments from commandline: a shell command and a file name. And thensend to child by using popen. Child process will implement the command with file as an input then sent to parent. Parent simply display output from the child on standard output.
 * ex) 
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <fcntl.h>

int main(int argc, char **argv){
  if(argc!=3){
    printf("Usage: ./task4 command filename\n");
    return 0;
  }
  
  //check input file
  int fd = open(argv[2], O_RDONLY);
  if(fd==-1){
    printf("Unable to open input file, exiting\n");
    return 0;
  }
  //Open the pipe
  FILE* p = popen("cat", "w");
  
  //Check if there are any problems
  if(p==NULL){
    printf("Pipe opened to null, exiting\n");
    return 0;
  }

  //buffer for reading file
  char buf[256];
  int n_read=read(fd,buf,256);
  while(n_read>0){
    fwrite(buf, sizeof(char), n_read, p);
    memset(buf, '\0', 256);
    n_read = read(fd, buf, 256);
  }
  
  pclose(p);
  return 0;
}
